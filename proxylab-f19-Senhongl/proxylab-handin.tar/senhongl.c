
#include "csapp.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>
#include <stdbool.h>
#include <inttypes.h>
#include <unistd.h>
#include <assert.h>

#include <pthread.h>
#include <signal.h>
#include <errno.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>

int main(int argc, char **argv) {
    char host[MAXLINE], path[MAXLINE], port[MAXLINE];
    char *buf = "http://www.baidu.com:8080/hub/index.html";

    if (sscanf(buf, "http://%[a-zA-Z.]:%[0-9]/%s[^\n]", host, port, path) == 3);
    else if (sscanf(buf, "http://%[a-zA-Z.]/%s", host, path) == 2);
    else if (sscanf(buf, "http://%[a-zA-Z.]:%[0-9]", host, port) == 2);
    else if (sscanf(buf, "http://%s", host) == 1);

    printf("%s\n", host);
    printf("%s\n", path);
    printf("%s\n", port);
}